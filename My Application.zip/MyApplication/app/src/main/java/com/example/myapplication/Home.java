package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        // Find the Login and Sign Up buttons
        Button loginButton = findViewById(R.id.Login);
        Button signupButton = findViewById(R.id.Signup);

        // Set click listener for Login button
        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, Login.class);
            startActivity(intent);
        });

        // Set click listener for Sign Up button
        signupButton.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, sign_up.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}